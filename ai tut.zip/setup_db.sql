-- ============================================
-- Database Setup for AI Programming Tutor
-- Run this script with your PostgreSQL superuser:
--   psql -U postgres -f setup_db.sql
-- ============================================

-- Create the database (if not exists)
SELECT 'CREATE DATABASE adaptive_tutor'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'adaptive_tutor')\gexec

-- Connect to the new database
\c adaptive_tutor

-- Grant privileges (using default postgres user for simplicity in dev)
GRANT ALL PRIVILEGES ON DATABASE adaptive_tutor TO postgres;

-- Success message
\echo '✓ Database "adaptive_tutor" is ready.'
