from sqlalchemy.ext.asyncio import AsyncSession
from app.models.admin import AuditLog

async def log_audit(db: AsyncSession, user_id: int, action: str, details: dict | None = None):
    audit_log = AuditLog(
        user_id=user_id,
        action=action,
        details=details
    )
    db.add(audit_log)
    await db.commit()
