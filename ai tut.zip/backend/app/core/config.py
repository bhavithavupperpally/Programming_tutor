from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    DATABASE_URL: str
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    PISTON_URL: str = "http://localhost:2000"
    GEMINI_API_KEY: str = "not-set-yet"
    EMAIL_ENABLED: bool = False

    model_config = SettingsConfigDict(env_file=".env")

settings = Settings()
