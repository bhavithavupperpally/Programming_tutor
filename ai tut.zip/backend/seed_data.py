import asyncio
from app.core.database import async_session_maker
from app.models.user import Role, User, Teacher
from app.models.course import Topic
from app.models.admin import Setting
from app.core.security import hash_password
from sqlalchemy import select

async def seed_data():
    async with async_session_maker() as session:
        # 1. Create roles
        roles_data = ["student", "teacher", "admin"]
        for role_name in roles_data:
            result = await session.execute(select(Role).where(Role.name == role_name))
            if not result.scalar_one_or_none():
                session.add(Role(name=role_name))
        await session.commit()
        print("Roles seeded.")
        
        # 2. Create topics
        topics_data = ["Arrays", "Loops", "Strings", "Recursion", "Sorting", "Linked Lists", "Stacks & Queues", "Trees", "Dynamic Programming", "Graphs"]
        for topic_name in topics_data:
            result = await session.execute(select(Topic).where(Topic.name == topic_name))
            if not result.scalar_one_or_none():
                session.add(Topic(name=topic_name))
        await session.commit()
        print("Topics seeded.")
        
        # 3. Create default admin
        admin_role = (await session.execute(select(Role).where(Role.name == "admin"))).scalar_one()
        admin_result = await session.execute(select(User).where(User.email == "admin@tutor.dev"))
        if not admin_result.scalar_one_or_none():
            admin_user = User(
                name="Admin",
                email="admin@tutor.dev",
                password_hash=hash_password("admin123"),
                role_id=admin_role.id
            )
            session.add(admin_user)
            await session.commit()
            print("Admin user seeded.")
            
        # 4. Create default teacher
        teacher_role = (await session.execute(select(Role).where(Role.name == "teacher"))).scalar_one()
        teacher_result = await session.execute(select(User).where(User.email == "teacher@tutor.dev"))
        if not teacher_result.scalar_one_or_none():
            teacher_user = User(
                name="Demo Teacher",
                email="teacher@tutor.dev",
                password_hash=hash_password("teacher123"),
                role_id=teacher_role.id
            )
            session.add(teacher_user)
            await session.flush()
            session.add(Teacher(user_id=teacher_user.id))
            await session.commit()
            print("Teacher user seeded.")
            
        # 5. Create default settings
        settings_data = [
            {"key": "ai_provider", "value": {"provider": "gemini"}},
            {"key": "hint_verbosity", "value": {"level": "medium"}}
        ]
        for s in settings_data:
            result = await session.execute(select(Setting).where(Setting.key == s["key"]))
            if not result.scalar_one_or_none():
                session.add(Setting(key=s["key"], value=s["value"]))
        await session.commit()
        print("Settings seeded.")
        
if __name__ == "__main__":
    asyncio.run(seed_data())
