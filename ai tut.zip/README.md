# AI-Powered Adaptive Programming Tutor

A production-grade adaptive programming learning platform with real code execution, AI-powered progressive hints, rule-based skill profiling, and a recommendation engine.

## Architecture

- **Frontend**: React + TypeScript + Vite + Tailwind CSS v4 + TanStack Query + Monaco Editor
- **Backend**: Python + FastAPI + SQLAlchemy (async) + Pydantic v2
- **Database**: PostgreSQL 17 + Alembic migrations
- **Code Execution**: Piston API (self-hosted via Docker)
- **AI**: Google Gemini API (swappable via AIProvider interface)

## Prerequisites

- Node.js 22+ and npm
- Python 3.10+
- PostgreSQL 17+
- Docker (for Piston code execution)

---

## Phase 1 — Foundation

### What was added
- FastAPI backend with JWT authentication (register/login/logout/password reset)
- Role-based access control (student/teacher/admin)
- Full database schema (15 tables) with Alembic migrations
- React frontend with premium dark-mode UI
- Protected routes per role
- Dashboard shells for student, teacher, admin

### Setup Instructions

#### 1. Database Setup
```bash
# Create the database (enter your postgres password when prompted)
psql -U postgres -f setup_db.sql
```

#### 2. Backend Setup
```bash
cd backend

# Create and activate virtual environment
python -m venv venv
.\venv\Scripts\activate        # Windows PowerShell

# Install dependencies
pip install -r requirements.txt

# Copy environment config
copy .env.example .env
# Edit .env with your PostgreSQL password if needed

# Run database migrations
alembic upgrade head

# Seed initial data (roles, topics, admin/teacher users)
python seed_data.py

# Start the backend server
uvicorn app.main:app --reload --port 8000
```

#### 3. Frontend Setup
```bash
cd frontend

# Install dependencies
npm install

# Start the dev server (proxies /api to backend on port 8000)
npm run dev
```

#### 4. Access the App
Open http://localhost:5173

**Default accounts:**
| Role    | Email              | Password    |
|---------|--------------------|-------------|
| Admin   | admin@tutor.dev    | admin123    |
| Teacher | teacher@tutor.dev  | teacher123  |

Register a new account to test the student flow.

### Smoke Test Checklist
- [ ] Open http://localhost:5173 → redirects to login page
- [ ] Click "Create Account" → register as student
- [ ] Login with new student account → see student dashboard
- [ ] Login as teacher@tutor.dev → see teacher dashboard
- [ ] Login as admin@tutor.dev → see admin dashboard
- [ ] Try accessing /admin/dashboard as student → redirected to student dashboard
- [ ] Logout → redirected to login page
