import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, LoginRequest, RegisterRequest } from '../types';
import { useLogin, useRegister, useCurrentUser } from '../api/hooks/useAuth';
import { useQueryClient } from '@tanstack/react-query';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (data: LoginRequest) => Promise<void>;
  register: (data: RegisterRequest) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(localStorage.getItem('access_token'));
  const queryClient = useQueryClient();
  
  const { data: user, isLoading: isUserLoading, isError } = useCurrentUser();
  const loginMutation = useLogin();
  const registerMutation = useRegister();

  const isLoading = isUserLoading || loginMutation.isPending || registerMutation.isPending;

  useEffect(() => {
    if (isError) {
      setToken(null);
      localStorage.removeItem('access_token');
    }
  }, [isError]);

  const login = async (data: LoginRequest) => {
    const response = await loginMutation.mutateAsync(data);
    localStorage.setItem('access_token', response.access_token);
    setToken(response.access_token);
    queryClient.setQueryData(['currentUser'], response.user);
  };

  const register = async (data: RegisterRequest) => {
    const response = await registerMutation.mutateAsync(data);
    localStorage.setItem('access_token', response.access_token);
    setToken(response.access_token);
    queryClient.setQueryData(['currentUser'], response.user);
  };

  const logout = () => {
    localStorage.removeItem('access_token');
    setToken(null);
    queryClient.setQueryData(['currentUser'], null);
  };

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        token,
        isAuthenticated: !!user && !!token,
        isLoading,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
