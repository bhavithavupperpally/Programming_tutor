import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Card } from '../../components/ui/Card';
import { Users, BookOpen, Activity, GraduationCap, ChevronRight } from 'lucide-react';
import { Button } from '../../components/ui/Button';

export const TeacherDashboard: React.FC = () => {
  const { user } = useAuth();

  const stats = [
    { label: 'Total Students', value: '128', icon: <Users className="w-6 h-6 text-brand-400" />, color: 'from-brand-500/20 to-brand-500/5' },
    { label: 'Active Today', value: '45', icon: <Activity className="w-6 h-6 text-emerald-400" />, color: 'from-emerald-500/20 to-emerald-500/5' },
    { label: 'Exercises Created', value: '24', icon: <BookOpen className="w-6 h-6 text-purple-400" />, color: 'from-purple-500/20 to-purple-500/5' },
    { label: 'Avg Class Score', value: '82%', icon: <GraduationCap className="w-6 h-6 text-amber-400" />, color: 'from-amber-500/20 to-amber-500/5' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Teacher Dashboard</h1>
          <p className="text-surface-400 text-lg">Manage your classes and monitor student progress.</p>
        </div>
        <Button className="shrink-0 shadow-brand-500/20">
          Create New Exercise
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <Card 
            key={i} 
            padding="lg" 
            className={`bg-gradient-to-br ${stat.color} border-surface-700/50 hover:border-surface-600 transition-colors animate-fade-in`}
            style={{ animationFillMode: 'both', animationDelay: `${i * 100}ms` }}
          >
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-surface-900/50 border border-surface-700/50 shadow-inner">
                {stat.icon}
              </div>
              <div>
                <p className="text-sm font-medium text-surface-400">{stat.label}</p>
                <p className="text-2xl font-bold text-white mt-1">{stat.value}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
        {/* Needs Attention */}
        <section className="animate-fade-in" style={{ animationDelay: '400ms', animationFillMode: 'both' }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Students Needing Attention</h2>
            <button className="text-sm text-brand-400 hover:text-brand-300 font-medium flex items-center">
              View all <ChevronRight className="w-4 h-4 ml-1" />
            </button>
          </div>
          <Card className="bg-surface-800/30 min-h-[300px] flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-full bg-surface-800 flex items-center justify-center mb-4 border border-surface-700">
              <Users className="w-8 h-8 text-surface-500" />
            </div>
            <h3 className="text-lg font-medium text-white mb-2">All caught up!</h3>
            <p className="text-surface-400 max-w-xs mx-auto">
              No students are currently stuck or falling behind on their exercises.
            </p>
          </Card>
        </section>

        {/* Recent Submissions */}
        <section className="animate-fade-in" style={{ animationDelay: '500ms', animationFillMode: 'both' }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Recent Submissions</h2>
            <button className="text-sm text-brand-400 hover:text-brand-300 font-medium flex items-center">
              View all <ChevronRight className="w-4 h-4 ml-1" />
            </button>
          </div>
          <Card className="bg-surface-800/30 min-h-[300px] flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-full bg-surface-800 flex items-center justify-center mb-4 border border-surface-700">
              <BookOpen className="w-8 h-8 text-surface-500" />
            </div>
            <h3 className="text-lg font-medium text-white mb-2">No recent submissions</h3>
            <p className="text-surface-400 max-w-xs mx-auto">
              Students haven't submitted any new code for review yet.
            </p>
          </Card>
        </section>
      </div>
    </div>
  );
};
