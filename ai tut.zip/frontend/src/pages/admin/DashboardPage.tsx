import React from 'react';
import { Card } from '../../components/ui/Card';
import { Users, Server, ShieldCheck, Activity, Settings, FileText, Database } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const stats = [
    { label: 'Total Users', value: '1,248', icon: <Users className="w-6 h-6 text-brand-400" /> },
    { label: 'Active Today', value: '342', icon: <Activity className="w-6 h-6 text-emerald-400" /> },
    { label: 'Submissions Today', value: '8,942', icon: <Database className="w-6 h-6 text-purple-400" /> },
    { label: 'System Health', value: '99.9%', icon: <Server className="w-6 h-6 text-amber-400" /> },
  ];

  const quickActions = [
    { label: 'Manage Users', icon: <Users className="w-5 h-5" />, desc: 'Add, edit or ban platform users' },
    { label: 'AI Settings', icon: <Settings className="w-5 h-5" />, desc: 'Configure LLM prompts and limits' },
    { label: 'Audit Log', icon: <FileText className="w-5 h-5" />, desc: 'Review system events and actions' },
    { label: 'Security', icon: <ShieldCheck className="w-5 h-5" />, desc: 'Manage roles and permissions' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Admin Control Panel</h1>
        <p className="text-surface-400 text-lg">System overview and administrative actions.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <Card 
            key={i} 
            padding="lg" 
            className="bg-surface-800/40 border-surface-700/50 animate-fade-in"
            style={{ animationFillMode: 'both', animationDelay: `${i * 100}ms` }}
          >
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-surface-900/80 border border-surface-700/50">
                {stat.icon}
              </div>
              <div>
                <p className="text-sm font-medium text-surface-400">{stat.label}</p>
                <p className="text-2xl font-bold text-white mt-1">{stat.value}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
        {/* Quick Actions */}
        <section className="lg:col-span-1 animate-fade-in" style={{ animationDelay: '400ms', animationFillMode: 'both' }}>
          <h2 className="text-xl font-semibold text-white mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 gap-3">
            {quickActions.map((action, i) => (
              <button 
                key={i}
                className="flex items-start gap-4 p-4 rounded-xl glass-light border-surface-700/50 hover:bg-surface-700/50 transition-colors text-left group"
              >
                <div className="p-2 rounded-lg bg-surface-800 text-brand-400 group-hover:text-brand-300 group-hover:bg-surface-900 transition-colors mt-0.5">
                  {action.icon}
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white group-hover:text-brand-300 transition-colors">{action.label}</h3>
                  <p className="text-xs text-surface-400 mt-1">{action.desc}</p>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Platform Overview */}
        <section className="lg:col-span-2 animate-fade-in" style={{ animationDelay: '500ms', animationFillMode: 'both' }}>
          <h2 className="text-xl font-semibold text-white mb-4">Platform Overview</h2>
          <Card className="bg-surface-800/30 h-[calc(100%-2.5rem)] min-h-[300px] flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 rounded-full bg-surface-800 flex items-center justify-center mb-4 border border-surface-700">
              <Activity className="w-8 h-8 text-surface-500" />
            </div>
            <h3 className="text-lg font-medium text-white mb-2">Systems Operating Normally</h3>
            <p className="text-surface-400 max-w-sm mx-auto">
              Detailed charts and graphs for system resources, API usage, and active sessions will appear here.
            </p>
          </Card>
        </section>
      </div>
    </div>
  );
};
