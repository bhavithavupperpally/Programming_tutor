import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Card } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { Code2, Target, Flame, Trophy, ChevronRight, Play } from 'lucide-react';

export const StudentDashboard: React.FC = () => {
  const { user } = useAuth();

  const stats = [
    { label: 'Problems Solved', value: '42', icon: <Code2 className="w-6 h-6 text-brand-400" />, color: 'from-brand-500/20 to-brand-500/5' },
    { label: 'Success Rate', value: '87%', icon: <Target className="w-6 h-6 text-emerald-400" />, color: 'from-emerald-500/20 to-emerald-500/5' },
    { label: 'Current Streak', value: '5 Days', icon: <Flame className="w-6 h-6 text-amber-400" />, color: 'from-amber-500/20 to-amber-500/5' },
    { label: 'Skill Level', value: 'Intermediate', icon: <Trophy className="w-6 h-6 text-purple-400" />, color: 'from-purple-500/20 to-purple-500/5' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Welcome back, {user?.name?.split(' ')[0]}! 👋</h1>
        <p className="text-surface-400 text-lg">Ready to tackle some new programming challenges today?</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <Card 
            key={i} 
            padding="lg" 
            className={`bg-gradient-to-br ${stat.color} border-surface-700/50 hover:border-surface-600 transition-colors delay-${i * 100} animate-fade-in`}
            style={{ animationFillMode: 'both', animationDelay: `${i * 100}ms` }}
          >
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-surface-900/50 border border-surface-700/50 shadow-inner">
                {stat.icon}
              </div>
              <div>
                <p className="text-sm font-medium text-surface-400">{stat.label}</p>
                <p className="text-2xl font-bold text-white mt-1">{stat.value}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content Area */}
        <div className="lg:col-span-2 space-y-8">
          {/* Recommended Next */}
          <section className="animate-fade-in" style={{ animationDelay: '400ms', animationFillMode: 'both' }}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-white">Recommended Next</h2>
              <button className="text-sm text-brand-400 hover:text-brand-300 font-medium flex items-center">
                View all <ChevronRight className="w-4 h-4 ml-1" />
              </button>
            </div>
            <Card hover className="bg-surface-800/40 border-brand-500/20 group cursor-pointer relative overflow-hidden">
              <div className="absolute top-0 left-0 w-1 h-full bg-brand-500" />
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <Badge variant="info">Python</Badge>
                    <Badge variant="warning">Medium</Badge>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-brand-400 transition-colors">Implement Binary Search Tree</h3>
                  <p className="text-surface-400 text-sm max-w-xl">
                    Practice your data structure skills by implementing a binary search tree with insert, delete, and search operations.
                  </p>
                </div>
                <div className="w-12 h-12 rounded-full bg-brand-500/20 flex items-center justify-center group-hover:bg-brand-500 transition-colors shrink-0">
                  <Play className="w-5 h-5 text-brand-400 group-hover:text-white ml-1 transition-colors" />
                </div>
              </div>
            </Card>
          </section>

          {/* Recent Activity */}
          <section className="animate-fade-in" style={{ animationDelay: '500ms', animationFillMode: 'both' }}>
            <h2 className="text-xl font-semibold text-white mb-4">Recent Activity</h2>
            <Card className="bg-surface-800/20">
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="w-16 h-16 rounded-full bg-surface-800 flex items-center justify-center mb-4 border border-surface-700">
                  <History className="w-8 h-8 text-surface-500" />
                </div>
                <h3 className="text-lg font-medium text-white mb-2">No recent activity</h3>
                <p className="text-surface-400 max-w-sm">
                  You haven't solved any problems recently. Start with the recommended exercise above!
                </p>
              </div>
            </Card>
          </section>
        </div>

        {/* Sidebar Area */}
        <div className="space-y-8">
          {/* Skill Profile */}
          <section className="animate-fade-in" style={{ animationDelay: '600ms', animationFillMode: 'both' }}>
            <h2 className="text-xl font-semibold text-white mb-4">Skill Profile</h2>
            <Card className="bg-surface-800/30">
              <div className="space-y-6">
                {[
                  { name: 'Variables & Types', progress: 95, color: 'bg-brand-500' },
                  { name: 'Control Flow', progress: 80, color: 'bg-emerald-500' },
                  { name: 'Functions', progress: 65, color: 'bg-amber-500' },
                  { name: 'Data Structures', progress: 40, color: 'bg-purple-500' },
                  { name: 'Algorithms', progress: 25, color: 'bg-rose-500' },
                ].map((skill, idx) => (
                  <div key={idx}>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-surface-200 font-medium">{skill.name}</span>
                      <span className="text-surface-400">{skill.progress}%</span>
                    </div>
                    <div className="h-2 bg-surface-700 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${skill.color} rounded-full`}
                        style={{ width: `${skill.progress}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </section>
        </div>
      </div>
    </div>
  );
};
