import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { 
  LayoutDashboard, 
  BookOpen, 
  History, 
  UserCircle, 
  Users, 
  BarChart3, 
  Settings, 
  ShieldAlert
} from 'lucide-react';

interface NavItem {
  label: string;
  path: string;
  icon: React.ReactNode;
}

export const Sidebar: React.FC = () => {
  const { user } = useAuth();

  const getNavItems = (): NavItem[] => {
    switch (user?.role) {
      case 'student':
        return [
          { label: 'Dashboard', path: '/student/dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
          { label: 'Problems', path: '/student/problems', icon: <BookOpen className="w-5 h-5" /> },
          { label: 'History', path: '/student/history', icon: <History className="w-5 h-5" /> },
          { label: 'Profile', path: '/student/profile', icon: <UserCircle className="w-5 h-5" /> },
        ];
      case 'teacher':
        return [
          { label: 'Dashboard', path: '/teacher/dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
          { label: 'Exercises', path: '/teacher/exercises', icon: <BookOpen className="w-5 h-5" /> },
          { label: 'Students', path: '/teacher/students', icon: <Users className="w-5 h-5" /> },
          { label: 'Analytics', path: '/teacher/analytics', icon: <BarChart3 className="w-5 h-5" /> },
        ];
      case 'admin':
        return [
          { label: 'Dashboard', path: '/admin/dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
          { label: 'Users', path: '/admin/users', icon: <Users className="w-5 h-5" /> },
          { label: 'Settings', path: '/admin/settings', icon: <Settings className="w-5 h-5" /> },
          { label: 'Audit Log', path: '/admin/audit', icon: <ShieldAlert className="w-5 h-5" /> },
        ];
      default:
        return [];
    }
  };

  const navItems = getNavItems();

  return (
    <aside className="w-64 hidden lg:block glass border-r border-surface-700/50 h-[calc(100vh-4rem)] sticky top-16 overflow-y-auto">
      <div className="p-4 space-y-2">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'bg-brand-500/10 text-brand-400 font-medium border border-brand-500/20 shadow-[inset_0_0_20px_rgba(59,130,246,0.1)]'
                  : 'text-surface-300 hover:text-white hover:bg-surface-800'
              }`
            }
          >
            {item.icon}
            {item.label}
          </NavLink>
        ))}
      </div>
    </aside>
  );
};
