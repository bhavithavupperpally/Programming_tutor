import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { LogOut, User as UserIcon, Code2, ChevronDown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="sticky top-0 z-50 glass border-b border-surface-700/50 px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Code2 className="w-8 h-8 text-brand-500" />
        <span className="text-xl font-bold tracking-tight gradient-text">
          AdaptiveCode
        </span>
      </div>

      {user && (
        <div className="relative">
          <button
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="flex items-center gap-2 hover:bg-surface-800/50 rounded-full py-1 px-3 transition-colors focus:outline-none"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-500 to-purple-500 flex items-center justify-center text-white font-medium shadow-md">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <span className="text-sm font-medium text-surface-200 hidden sm:block">
              {user.name}
            </span>
            <ChevronDown className="w-4 h-4 text-surface-400" />
          </button>

          {isDropdownOpen && (
            <div className="absolute right-0 mt-2 w-48 glass rounded-xl shadow-lg shadow-black/50 py-1 border border-surface-700/50 animate-fade-in">
              <div className="px-4 py-2 border-b border-surface-700/50 mb-1">
                <p className="text-sm font-medium text-white truncate">{user.name}</p>
                <p className="text-xs text-surface-400 truncate">{user.email}</p>
              </div>
              <button
                className="w-full text-left px-4 py-2 text-sm text-surface-300 hover:bg-surface-800 hover:text-white flex items-center gap-2 transition-colors"
                onClick={() => setIsDropdownOpen(false)}
              >
                <UserIcon className="w-4 h-4" /> Profile
              </button>
              <button
                onClick={handleLogout}
                className="w-full text-left px-4 py-2 text-sm text-error hover:bg-surface-800 flex items-center gap-2 transition-colors"
              >
                <LogOut className="w-4 h-4" /> Sign out
              </button>
            </div>
          )}
        </div>
      )}
    </nav>
  );
};
