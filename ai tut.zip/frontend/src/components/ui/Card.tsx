import React from 'react';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  header?: React.ReactNode;
  padding?: 'none' | 'sm' | 'md' | 'lg';
  hover?: boolean;
}

export const Card: React.FC<CardProps> = ({
  children,
  header,
  padding = 'md',
  hover = false,
  className = '',
  ...props
}) => {
  const paddings = {
    none: '',
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8',
  };

  return (
    <div
      className={`glass rounded-xl overflow-hidden ${
        hover ? 'transition-transform duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-brand-500/10' : ''
      } ${className}`}
      {...props}
    >
      {header && (
        <div className="px-6 py-4 border-b border-surface-700/50 bg-surface-800/30">
          {header}
        </div>
      )}
      <div className={paddings[padding]}>{children}</div>
    </div>
  );
};
