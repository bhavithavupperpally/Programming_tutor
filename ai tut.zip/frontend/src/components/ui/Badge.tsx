import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'success' | 'warning' | 'error' | 'info' | 'neutral';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({ children, variant = 'neutral', className = '' }) => {
  const variants = {
    success: 'bg-success/20 text-emerald-400 border-success/30',
    warning: 'bg-warning/20 text-amber-400 border-warning/30',
    error: 'bg-error/20 text-rose-400 border-error/30',
    info: 'bg-brand-500/20 text-brand-300 border-brand-500/30',
    neutral: 'bg-surface-700/50 text-surface-300 border-surface-600',
  };

  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border backdrop-blur-sm ${variants[variant]} ${className}`}
    >
      {children}
    </span>
  );
};
