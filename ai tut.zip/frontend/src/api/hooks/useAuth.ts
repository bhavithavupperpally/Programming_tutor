import { useMutation, useQuery } from '@tanstack/react-query';
import { api } from '../client';
import { LoginRequest, RegisterRequest, TokenResponse, User } from '../../types';

export const useLogin = () => {
  return useMutation({
    mutationFn: async (data: LoginRequest) => {
      const response = await api.post<TokenResponse>('/api/auth/login', data);
      return response.data;
    },
  });
};

export const useRegister = () => {
  return useMutation({
    mutationFn: async (data: RegisterRequest) => {
      const response = await api.post<TokenResponse>('/api/auth/register', data);
      return response.data;
    },
  });
};

export const useCurrentUser = () => {
  return useQuery({
    queryKey: ['currentUser'],
    queryFn: async () => {
      const response = await api.get<User>('/api/auth/me');
      return response.data;
    },
    retry: false,
  });
};
